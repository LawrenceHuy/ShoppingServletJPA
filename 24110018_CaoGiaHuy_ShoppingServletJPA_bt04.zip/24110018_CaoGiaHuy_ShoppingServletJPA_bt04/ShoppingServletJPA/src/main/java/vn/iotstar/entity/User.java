package vn.iotstar.entity;

import java.io.Serializable;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "Users")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "email", columnDefinition = "nvarchar(255) not null")
    private String email;

    @Column(name = "username", columnDefinition = "nvarchar(255) not null", unique = true)
    private String userName;

    @Column(name = "fullname", columnDefinition = "nvarchar(255) null")
    private String fullName;

    @Column(name = "password", columnDefinition = "nvarchar(255) not null")
    private String passWord;

    @Column(name = "avatar", columnDefinition = "nvarchar(255) null")
    private String avatar;

    @Column(name = "roleid")
    private int roleid;

    @Column(name = "phone", columnDefinition = "nvarchar(50) null")
    private String phone;

    @Column(name = "createddate")
    private Date createdDate;

    // false = chưa kích hoạt qua OTP email (default 1 để các user cũ có sẵn trong DB vẫn đăng nhập được)
    @Column(name = "active", columnDefinition = "bit not null default 1")
    private boolean active;

    // one-to-many: 1 user có nhiều video (phía "1" của quan hệ 1-n)
    @OneToMany(mappedBy = "user")
    private List<Video> videos = new ArrayList<>();

    public User() {}

    public User(String email, String userName, String fullName, String passWord,
                String avatar, int roleid, String phone, Date createdDate) {
        this.email = email; this.userName = userName; this.fullName = fullName;
        this.passWord = passWord; this.avatar = avatar; this.roleid = roleid;
        this.phone = phone; this.createdDate = createdDate;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPassWord() { return passWord; }
    public void setPassWord(String passWord) { this.passWord = passWord; }
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    public int getRoleid() { return roleid; }
    public void setRoleid(int roleid) { this.roleid = roleid; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public Date getCreatedDate() { return createdDate; }
    public void setCreatedDate(Date createdDate) { this.createdDate = createdDate; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public List<Video> getVideos() { return videos; }
    public void setVideos(List<Video> videos) { this.videos = videos; }

    /** Đường dẫn avatar dùng với &lt;c:url&gt;; rỗng nếu chưa có avatar. */
    public String getAvatarPath() {
        if (avatar == null || avatar.isBlank()) return "";
        if (avatar.startsWith("http")) return avatar;
        return "/image?fname=" + URLEncoder.encode(avatar, StandardCharsets.UTF_8);
    }
}
